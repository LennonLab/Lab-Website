from __future__ import division
import  matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import os

mydir = os.path.expanduser('~/GitHub/residence-time')
tools = os.path.expanduser(mydir + "/tools")


def assigncolor(xs):
    cDict = {}
    clrs = []
    for x in xs:
        if x not in cDict:
            if x <= 1: c = 'r'
            elif x <= 2: c = 'Orange'
            elif x <= 3: c = 'Green'
            elif x <= 4: c = 'DodgerBlue'
            elif x <= 5: c = 'Plum'
            else: c = 'Purple'
            cDict[x] = c

        clrs.append(cDict[x])
    return clrs




df = pd.read_csv(mydir + '/Model/results/data/SimData.csv')

df2 = pd.DataFrame({'N' : df['active.total.abundance'].groupby(df['sim']).mean()})
df2['P'] = df['ind.production'].groupby(df['sim']).mean()

df2['tau'] = df['V'].groupby(df['sim']).mean()/df['Q'].groupby(df['sim']).mean()

df2['size'] = df['active.avg.per.capita.size'].groupby(df['sim']).mean()
df2['mu'] = df['active.growth'].groupby(df['sim']).mean()
df2['d'] = df['active.dispersal'].groupby(df['sim']).mean()
df2['B'] = df['active.maint'].groupby(df['sim']).mean()

df2['x1'] = df2['d'] * df2['tau'] * 0.2
df2['x2'] = df2['B'] * df2['tau'] * 0.2
df2['x3'] = df2['mu'] * df2['tau'] * 0.2

clrs = assigncolor(np.log10(df2['tau']))

v = 1
fs = 7
fig = plt.figure()
sz = 0.5
w = 0.75
b = 100
ci = 99

#### plot figures ##############################################################
xlab =  r'$\tau$'+' * Active dispersal rate '+r'$(d)$'

#### N vs. Tau #################################################################
fig.add_subplot(3, 3, 1)
x = df2['x1']
y = df2['N']

plt.axvline(v, color='k', ls=':', lw = w)
plt.scatter(x, y, s = sz, color=clrs, linewidths=0.0, edgecolor=None)
plt.ylabel('Total active\nabundance, '+r'$N_{a}$', fontsize=fs)
plt.xlabel(xlab, fontsize=fs)
plt.xscale('log')
plt.yscale('log')
plt.tick_params(axis='both', which='major', labelsize=fs-2)

#### production vs. Tau ########################################################
fig.add_subplot(3, 3, 2)
x = df2['x1']
y = df2['P']

plt.axvline(v, color='k', ls=':', lw = w)
plt.scatter(x, y, s = sz, color=clrs, linewidths=0.0, edgecolor=None)
plt.ylabel('Productivity, '+r'$P$', fontsize=fs)
plt.xlabel(xlab, fontsize=fs)
plt.ylim(0.01,60)
plt.xscale('log')
plt.yscale('log')
plt.tick_params(axis='both', which='major', labelsize=fs-2)



#### plot figures ##############################################################
xlab =  r'$\tau$'+' * Basal metabolic rate '+r'$(B)$'

#### N vs. Tau #################################################################
fig.add_subplot(3, 3, 4)
x = df2['x2']
y = df2['N']

plt.axvline(v, color='k', ls=':', lw = w)
plt.scatter(x, y, s = sz, color=clrs, linewidths=0.0, edgecolor=None)
plt.ylabel('Total active\nabundance, '+r'$N_{a}$', fontsize=fs)
plt.xlabel(xlab, fontsize=fs)
plt.xscale('log')
plt.yscale('log')
plt.tick_params(axis='both', which='major', labelsize=fs-2)

#### production vs. Tau ########################################################
fig.add_subplot(3, 3, 5)
x = df2['x2']
y = df2['P']

plt.axvline(v, color='k', ls=':', lw = w)
plt.scatter(x, y, s = sz, color=clrs, linewidths=0.0, edgecolor=None)
plt.ylabel('Productivity, '+r'$P$', fontsize=fs)
plt.xlabel(xlab, fontsize=fs)
plt.ylim(0.01,60)
plt.xscale('log')
plt.yscale('log')
plt.tick_params(axis='both', which='major', labelsize=fs-2)


#### plot figures ##############################################################
xlab =  r'$\tau$'+' * Individual growth rate '+r'$(\mu)$'

#### N vs. Tau #################################################################
fig.add_subplot(3, 3, 7)
x = df2['x3']
y = df2['N']

plt.axvline(v, color='k', ls=':', lw = w)
plt.scatter(x, y, s = sz, color=clrs, linewidths=0.0, edgecolor=None)
plt.ylabel('Total active\nabundance, '+r'$N_{a}$', fontsize=fs)
plt.xlabel(xlab, fontsize=fs)
plt.xscale('log')
plt.yscale('log')
plt.tick_params(axis='both', which='major', labelsize=fs-2)

#### production vs. Tau ########################################################
fig.add_subplot(3, 3, 8)
x = df2['x3']
y = df2['P']

plt.axvline(v, color='k', ls=':', lw = w)
plt.scatter(x, y, s = sz, color=clrs, linewidths=0.0, edgecolor=None)
plt.ylabel('Productivity, '+r'$P$', fontsize=fs)
plt.xlabel(xlab, fontsize=fs)
plt.ylim(0.01,60)
plt.xscale('log')
plt.yscale('log')
plt.tick_params(axis='both', which='major', labelsize=fs-2)

#### Final Format and Save #####################################################
plt.subplots_adjust(wspace=0.55, hspace=0.55)
plt.savefig(mydir + '/Model/results/figures/BMR_vs_Tau-3x3.eps', dpi=200, bbox_inches = "tight")
plt.close()
